# LLM Rerun

We inspected all 348 Java benchmark files and neutralized potentially cue-bearing identifiers, strings, and comments in 122 files, including 84 violating files and 38 compliant files. Code structure and line counts were preserved.

DeepSeek was rerun five times using the same prompt and evaluation procedure as the original experiment. Each run was evaluated independently, and the reported Precision, Recall, F1, and rule-support results are arithmetic means across the five runs. The resulting mean Precision, Recall, and F1 are 0.788, 0.734, and 0.760, respectively.

Contents:

- `neutralized-files/`: the 122 neutralized Java files.
- `replacement_mapping.xlsx`: mappings between the original and neutralized files.
- `raw/`: raw outputs from the five DeepSeek runs.
- `metrics/`: per-run evaluation summaries.
