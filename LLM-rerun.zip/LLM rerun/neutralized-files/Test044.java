class Test044 {
  /**
   * URL < 100 chars.
   * See: https://example.com/api/v1/search?query=short
   */
  public class JavadocUrl1 {}

  /**
   * URL = 100 chars.
   * See: https://example.com/abcdefghijabcdefghijabcdefghijabcdefghijabcdefghijabcdefghijabcgjcdhij
   */
  public class JavadocUrl2 {}

  /**
   * URL > 100 chars.
   * See: https://example.com/data/io/x/module/path/api/with/module/use/by/routed/reference/by/system/field/notes
   */
  public class JavadocUrl3 {}
}
