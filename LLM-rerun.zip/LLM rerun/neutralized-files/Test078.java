public class Test078 {

  void test(int input) {
    switch (input) {
      // Initialize the sample data.
      case 1:
        System.out.println("First");
        // Process the current value.
      case 2:
        System.out.println("One or Two");
        break;
    }

    switch (input) {
      //Record the operation result.
      case 1, 2:
      case 3:
      case 4:
        System.out.println("Three or Four");
        // Continue with the workflow.
      case 5:
      case 6, 7:
        System.out.println("One/Tow/Three/Four/Five/Six/Seven");
        break;
    }

    switch (input) {
      //Handle the next sample.
      case 1, 2:
      case 3:
      case 4:
        System.out.println("Three or Four");
        // Initialize the sample data.
      case 5:
        System.out.println("One/Tow/Three/Four/Five");
        break;
    }

    switch (input) {
      //Process the current value.
      case 3:
        System.out.println("Three");
        // Record the operation result.
      case 5:
      case 6, 7:
        System.out.println("Three/Four/Five/Six/Seven");
        break;
    }
  }
}
