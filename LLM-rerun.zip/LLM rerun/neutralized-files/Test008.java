package com.example.project.module.scenario;

public class Test008 {
  public void greet() {
    System.out.println("Hello");
  }
}
