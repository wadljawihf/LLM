package com.example.
        project.module.scenario;

public class Test011 {
  public void greet() {
    System.out.println("Hello");
  }
}
