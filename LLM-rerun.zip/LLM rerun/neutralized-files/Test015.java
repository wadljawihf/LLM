import java.utils.reallyreallyreallyreallyreallyreallyreallyreallyreallyreallyreallyreallylong.manmade.scenario;

public class Test015 {
  public void printItems() {
    Stream.of("a", "b", "c").forEach(System.out::println);
  }
}
