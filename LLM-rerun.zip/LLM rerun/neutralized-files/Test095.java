public class Test095 {
  long new1 = 1000000000l;
  long new2 = 42l;
  long new3 = 0x1FABl;
  long new4 = 0b1010_1010_1010l;
}
