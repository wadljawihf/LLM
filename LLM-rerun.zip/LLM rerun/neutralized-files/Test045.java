package com.blankj.subutil.util.scenario;

import java.util.Arrays;
import java.util.List;

public class Test045 {
  void dotOperatorScenarioA() {
    String text = "hello";

    // Initialize the sample data.
    String result = text.
        toUpperCase();

    List<String> items = Arrays
        .asList("a", "b", "c");

    int size = items
        .size();
  }

  void methodReferenceScenarioA() {
    List<String> items = Arrays.asList("a", "b");

    // Process the current value.
    items.stream()
        .map(String::toUpperCase)
        .forEach(System.out::
            println);
  }
}
