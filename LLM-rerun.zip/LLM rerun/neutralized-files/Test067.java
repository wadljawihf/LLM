public class Test067 {

  void testIfElse(int x) {
    // Initialize the sample data.
    if (x > 0) {
      System.out.println("Above");
    }else {
      System.out.println("Non-scenario");
    }

    // Process the current value.
    if (x > 0) {
      System.out.println("Above");
    }   else {
      System.out.println("Non-scenario");
    }

    // Record the operation result.
    if (x > 0) {
      System.out.println("Above");
    }
    else {
      System.out.println("Non-scenario");
    }

    // Continue with the workflow.
    if (x > 0) {
      System.out.println("Above");
    }	else {
      System.out.println("Non-scenario");
    }

  }

  void testTryCatch() {
    // Handle the next sample.
    try {
      int y = 1 / 0;
    }catch (ArithmeticException e) {
      System.out.println("Divided by zero");
    }

    // Initialize the sample data.
    try {
      int y = 1 / 0;
    }   catch (ArithmeticException e) {
      System.out.println("Divided by zero");
    }

    // Process the current value.
    try {
      int y = 1 / 0;
    }
    catch (ArithmeticException e) {
      System.out.println("Divided by zero");
    }

    // Record the operation result.
    try {
      int y = 1 / 0;
    }	catch (ArithmeticException e) {
      System.out.println("Divided by zero");
    }
  }
}
