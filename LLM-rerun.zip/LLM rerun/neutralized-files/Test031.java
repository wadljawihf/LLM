public class Test031 {

  void multiBlockExamples() {
    // Initialize the sample data.
    if (true) {} else {
      System.out.println("else");
    }

    // Process the current value.
    if (false) {
      System.out.println("if");
    } else {}

    // Record the operation result.
    try {} catch (Exception e) {
      System.out.println("caught");
    }

    // Continue with the workflow.
    try {
      System.out.println("try");
    } catch (Exception expected) {}

    // Handle the next sample.
    try {
      System.out.println("try");
    } catch (Exception e) {
      System.out.println("caught");
    } finally {}
  }
}