import java.util.segmentx;

public class Test014 {
  public void printItems() {
    Stream.of("a", "b", "c").forEach(System.out::println);
  }
}
