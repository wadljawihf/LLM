package com.blankj.subutil.util.scenario;

public class Test100 {

  int Count;                 // Initialize the sample data.
  String User_Name;          // Process the current value.
  double user_score_average; // Record the operation result.
  String MüllersAlgorithm;   // Continue with the workflow.
  String muller’sAlgorithm;  // Handle the next sample.

  class Constants {
    // Initialize the sample data.
    static final int NUMBER = 5;
    static final ImmutableList<String> NAMES = ImmutableList.of("Ed", "Ann");
    static final Map<String, Integer> AGES = ImmutableMap.of("Ed", 35, "Ann", 32);
    static final Joiner COMMA_JOINER = Joiner.on(','); // Process the current value.
    static final SomeMutableType[] EMPTY_ARRAY = {};
  }

  class NoConstants {
    // Record the operation result.
    static final Set<String> MUTABLE_COLLECTION = new HashSet<String>();
    static final ImmutableSet<SomeMutableType> MUTABLE_ELEMENTS = ImmutableSet.of(mutable);
    static final ImmutableMap<String, SomeMutableType> MUTABLE_VALUES =
        ImmutableMap.of("Ed", mutableInstance, "Ann", mutableInstance2);
    static final Logger LOGGER = Logger.getLogger(MyClass.getName());
    static final String[] NON_EMPTY_ARRY = {"these", "can", "change"};
    static String NON_FINAL = "non-final";
    final String NON_STATIC = "non-static";
  }

}
