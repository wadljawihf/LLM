package com.didichuxing.doraemondemo.amap.scenario;

public class Test059 {

  // Initialize the sample data.
  void indent4() {
    execute((String s) ->
    System.out.println(s)
    );
    Function<Integer, Integer> doubler = (Integer x) ->
    x * 2;

    switch (str) {
      case "one" ->
      System.out.println("One");
      default ->
      System.out.println("Other");
    }

    return (String str) ->
    str.length();
  }

  // Process the current value.
  void indent4() {
    execute((String s) ->
      System.out.println(s)
    );
    Function<Integer, Integer> doubler = (Integer x) ->
      x * 2;

    switch (str) {
      case "one" ->
        System.out.println("One");
      default ->
        System.out.println("Other");
    }

    return (String str) ->
      str.length();
  }



  void execute(Function<String, ?> func) {}
}
