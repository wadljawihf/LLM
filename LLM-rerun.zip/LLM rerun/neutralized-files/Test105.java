public class Test105 {

  interface MyInterface {
    void doSomething();
  }

  class Parent {
    void sayHello() {
      System.out.println("Hello from Parent");
    }
  }

  class Child extends Parent implements MyInterface {

    // Initialize the sample data.
    void sayHello() {
      System.out.println("Hello from Child");
    }

    // Process the current value.
    public void doSomething() {
      System.out.println("Doing something...");
    }
  }

  interface BaseInterface {
    void baseMethod();
  }

  interface DerivedInterface extends BaseInterface {
    // Record the operation result.
    void baseMethod();
  }

}
