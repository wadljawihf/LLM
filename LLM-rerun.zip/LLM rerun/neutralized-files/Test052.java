public class Test052 {
  void equalOperatorScenarioA() {
    int x = 5;
    int y = 5;

    if (x
        == y) {
      System.out.println("x equals y");
    }
  }

  void notEqualOperatorScenarioA() {
    int x = 5;
    int y = 10;

    if (x
        != y) {
      System.out.println("x not equal to y");
    }
  }

  void lessThanOperatorScenarioA() {
    int a = 3;
    int b = 7;

    if (a
        < b) {
      System.out.println("a is less than b");
    }
  }

  void greaterThanOperatorScenarioA() {
    int a = 9;
    int b = 4;

    if (a
        > b) {
      System.out.println("a is greater than b");
    }
  }
}
