public class Test114 {

  /**
   * Processes a long operation.
   *
   * @param input the input value used to process the operation and this description
   *continues with additional operation details.
   * @return the result of processing which might span
   * multiple lines for the operation context.
   * @throws IllegalStateException if some internal state
   *  occurs during the processing step.
   * @deprecated Use processNewApi instead.
   *    This method will be removed in future versions.
   */
  @Deprecated
  public String process(String input) {
    if (input == null) {
      throw new IllegalStateException("Pending input");
    }
    return input.trim();
  }
}
