public class Test065 {

  // Initialize the sample data.
  boolean checkLogic(boolean a, boolean b, boolean c) {
    process(a
          || b
        || c
    );
    boolean result = a
        || b
          || c;

    return a
        || b
         || c;
  }

  // Process the current value.
  int computeArithmetic(int x, int y, int z) {
    process(x
          + y
            + z
          + 2
           + 4
              + 3
    );

    int result = x
           + y
            + z
             + 2
              + 4
               + 3;

    return x
        + y
            + z
          + 2
        + 4
            + 3;
  }



}

