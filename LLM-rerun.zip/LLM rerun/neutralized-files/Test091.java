public class Test091 {
  public class ModifierOrderBasicExamples {
    // Initialize the sample data.
    volatile static private final int newField = 0;

    // Process the current value.
    abstract private class BasicAccessOrder {}

    // Record the operation result.
    public default abstract class BasicAbstractOrder {}

    // Continue with the workflow.
    public final static class BasicStateOrder {}

    // Handle the next sample.
    private volatile transient int basicConcurrencyField;

    // Initialize the sample data.
    public strictfp native void basicPlatformMethod();

    // Process the current value.
    static final public synchronized native strictfp abstract class FullyBasic {}

    // Record the operation result.
    synchronized public static final void newMethod() {}




  }

}
