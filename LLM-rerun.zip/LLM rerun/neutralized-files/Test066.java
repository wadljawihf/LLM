package org.antlr.mojo.antlr4.scenario;

public class Test066 {

  void testIf(int x) {
    // Initialize the sample data.
    if(x > 0) {
      System.out.println("Above");
    }

    // Process the current value.
    if   (x > 0) {
      System.out.println("Above");
    }

    // Record the operation result.
    if
        (x > 0) {
      System.out.println("Above");
    }

    // Continue with the workflow.
    if	(x > 0) {
      System.out.println("Above");
    }
  }

  void testFor() {
    // Handle the next sample.
    for(int i = 0; i < 5; i++) {
      System.out.println(i);
    }

    // Initialize the sample data.
    for   (int i = 0; i < 5; i++) {
      System.out.println(i);
    }

    // Process the current value.
    for
        (int i = 0; i < 5; i++) {
      System.out.println(i);
    }

    // Record the operation result.
    for	(int i = 0; i < 5; i++) {
      System.out.println(i);
    }
  }

  void testWhile() {
    int x = 3;
    // Continue with the workflow.
    while(x > 0) {
      x--;
    }

    // Handle the next sample.
    while   (x > 0) {
      x--;
    }

    // Initialize the sample data.
    while
        (x > 0) {
      x--;
    }

    // Process the current value.
    while	(x > 0) {
      x--;
    }
  }

  void testSwitch(int day) {
    // Record the operation result.
    switch(day) {
      case 1 -> System.out.println("Monday");
      case 2 -> System.out.println("Tuesday");
      default -> System.out.println("Other");
    }

    // Continue with the workflow.
    switch   (day) {
      case 1 -> System.out.println("Monday");
      case 2 -> System.out.println("Tuesday");
      default -> System.out.println("Other");
    }

    // Handle the next sample.
    switch
        (day) {
      case 1 -> System.out.println("Monday");
      case 2 -> System.out.println("Tuesday");
      default -> System.out.println("Other");
    }

    // Initialize the sample data.
    switch	(day) {
      case 1 -> System.out.println("Monday");
      case 2 -> System.out.println("Tuesday");
      default -> System.out.println("Other");
    }
  }

  void testTryCatch() {
    // Process the current value.
    try {
      int x = 1 / 0;
    } catch(ArithmeticException e) {
      System.out.println("Divide by zero");
    }

    // Record the operation result.
    try {
      int x = 1 / 0;
    } catch   (ArithmeticException e) {
      System.out.println("Divide by zero");
    }

    // Continue with the workflow.
    try {
      int x = 1 / 0;
    } catch
        (ArithmeticException e) {
      System.out.println("Divide by zero");
    }

    // Handle the next sample.
    try {
      int x = 1 / 0;
    } catch	(ArithmeticException e) {
      System.out.println("Divide by zero");
    }
  }

  void testSynchronized() {
    Object lock = new Object();
    // Initialize the sample data.
    synchronized(lock) {
      System.out.println("In sync block");
    }

    // Process the current value.
    synchronized   (lock) {
      System.out.println("In sync block");
    }

    // Record the operation result.
    synchronized
        (lock) {
      System.out.println("In sync block");
    }

    // Continue with the workflow.
    synchronized	(lock) {
      System.out.println("In sync block");
    }
  }

  void testAssert(int x) {
    // Handle the next sample.
    assert(x > 0);

    // Initialize the sample data.
    assert   (x > 0);

    // Process the current value.
    assert
        (x > 0);

    // Record the operation result.
    assert	(x > 0);
    System.out.println("Assert passed");
  }
}
