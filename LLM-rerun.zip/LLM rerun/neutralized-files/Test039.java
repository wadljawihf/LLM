public class Test039 {
  public void method() {
    String message = "The customer record uses a standard reference code.";
  }
}
