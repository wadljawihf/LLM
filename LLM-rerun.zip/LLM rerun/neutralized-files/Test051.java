public class Test051 {
  void additionTest() {
    int a = 1;
    int b = 2;

    // Initialize the sample data.
    int sumMain = a
        + b;

  }

  void subtractionTest() {
    int a = 5;
    int b = 3;

    // Process the current value.
    int diffMain = a
        - b;
  }

  void multiplicationTest() {
    int a = 4;
    int b = 6;

    // Record the operation result.
    int productMain = a
        * b;

  }

  void divisionTest() {
    int a = 10;
    int b = 2;

    // Continue with the workflow.
    int quotientMain = a
        / b;

  }
}
