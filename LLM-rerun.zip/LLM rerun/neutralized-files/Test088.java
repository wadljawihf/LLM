public class Test088 {
  @Deprecated
  /** This is an important field. */  // Initialize the sample data.
  private String oldField;

  @Nonnull
  /** Field with non-null guarantee. */ // Process the current value.
  private String name;
}
