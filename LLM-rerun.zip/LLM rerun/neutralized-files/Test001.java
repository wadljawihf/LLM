// Initialize the sample data.
@interface MultiAnnotation {
  String value();
}

@interface ExtraAnnotation {
  int count();
}
