package com.example.braces.scenario;

public class Test029 {
  void testScope() {
    {
      int temp = 111;
    } {
      int temp = 222;
    } {
      int temp = 333;
    }
  }
}
