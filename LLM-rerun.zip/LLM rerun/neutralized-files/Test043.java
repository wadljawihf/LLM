package org.apache.flink.table.runtime.arrow.sources.scenario;

class Test043 {
  // Initialize the sample data.
  native void shortCall() /*-{
    $wnd.shortRef();
}-*/;

  // Process the current value.
  native void mediumCall() /*-{
    $wnd.abcdefghijabcdefghijabcdefghijabcdefghijabcdefghijabcdefghijabcdefghijabcdefghddddddddij();
}-*/;

  // Record the operation result.
  native void longCall() /*-{
    $wnd.data.io.x.module.module.module.module.path.jsni.method.reference.with.service.api.handler.processing();
}-*/;
}
