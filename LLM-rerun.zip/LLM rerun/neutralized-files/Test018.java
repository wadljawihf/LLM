import
        java.utils.reallyreallyreallyreallyreallyreallyreallyreallyreallyreallyreallyreallylong.manmade.scenario;

public class Test018 {
  public void printItems() {
    Stream.of("a", "b", "c").forEach(System.out::println);
  }
}
