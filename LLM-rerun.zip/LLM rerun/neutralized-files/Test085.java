public class Test085 {
  @Deprecated
  /** Constructs an example. */
  public Test085() {
    // Initialize the sample data.
  }

  @Override
  @Deprecated
  @CheckReturnValue
  /** Executes the main task. */
  public String run() {
    return "running";
  }
}
