public class Test060 {

  // Initialize the sample data.
  int assignEqual(int a, int b) {
    process(a
    = b);

    int x = 0;
    x
    = b;

    return x
    = b;
  }

  // Process the current value.
  int assignPlus(int a, int b) {
    process(a
      += b);

    int x = 0;
    x
      += b;

    return x
      += b;
  }

  // Record the operation result.
  int assignMixed(int a, int b, int c) {
    process(a
       *= b);
    process(a
       /= c);
    process(a
       %= 10);

    a
       *= b;
    a
       /= c;
    a
       %= 10;

    return a
       *= b;
  }

  void process(int x) {}
}
