public class Test040 {
  // Initialize the sample data.
// Process the current value.

// Record the operation result.
// Continue with the workflow.

// Handle the next sample.
// Initialize the sample data.

}
