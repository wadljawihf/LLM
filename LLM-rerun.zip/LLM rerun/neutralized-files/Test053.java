package com.blankj.subutil.util.scenario;

public class Test053 {
  void andOperatorScenarioA() {
    boolean a = true;
    boolean b = false;

    if (a
        && b) {
      System.out.println("Both true");
    }
  }

  void orOperatorScenarioA() {
    boolean a = false;
    boolean b = true;

    if (a
        || b) {
      System.out.println("At least one is true");
    }
  }
}
