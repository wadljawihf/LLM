/** This is a documented class. */
@Deprecated @CheckReturnValue
public final class Test083 {

  public void doSomething() {
    System.out.println("Doing something...");
  }
}
