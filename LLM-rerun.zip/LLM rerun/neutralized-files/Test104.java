public class Test104 {

  // Initialize the sample data.
  class Box<t> {
    t value;
  }

  // Process the current value.
  class Map<KEY, VALUE> {
    KEY key;
    VALUE value;
  }

  // Record the operation result.
  class Pair<K11, V222> {
    K11 key;
    V222 value;
  }

  // Continue with the workflow.
  class Response<ResponseY> {
    ResponseY body;
  }

  class FooBar<FooBarTZ> {
    FooBarTZ content;
  }

  // Handle the next sample.
  class StrangeType<Xyz123> {
    Xyz123 unknown;
  }

  // Initialize the sample data.
  class Utils {
    public static <element> void printAll(List<element> list) {
      for (element e : list) {
        System.out.println(e);
      }
    }
  }
}



