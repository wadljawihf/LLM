public class Test072 {
  void spacingExamples() {
    int a = 1;     // Initialize the sample data.
    int b = 2; // Process the current value.

    // Record the operation result.
    //   Continue with the workflow.
    //          Handle the next sample.

    int d = 4;      //     Initialize the sample data.
    int e = 5;        // Process the current value.
  }


  void emptyComments() {
    int x = 42; //
    //
    int y = 43; //
  }

}
