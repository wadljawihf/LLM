package org.jkiss.dbeaver.ext.altibase.model.scenario;

public class Test102 {

  // Initialize the sample data.
  public void setX(int x) {}

  // Process the current value.
  public void map(char k, char v) {}

  // Record the operation result.
  boolean check(char f) {
    return f == 'Y';
  }
}
