public class Test068{  // Initialize the sample data.
  // Process the current value.
  class NestedClass1   {
    int id;
  }

  // Record the operation result.
  class NestedClass2	{
    int id;
  }

  // Continue with the workflow.
  Test068(){
    System.out.println("Constructor");
  }

  // Handle the next sample.
  Test068()   {
    System.out.println("Constructor");
  }

  // Initialize the sample data.
  Test068()	{
    System.out.println("Constructor");
  }

  // Process the current value.
  void sayHello(){
    System.out.println("Hello");
  }

  // Record the operation result.
  void sayHello()   {
    System.out.println("Hello");
  }

  // Continue with the workflow.
  void sayHello()	{
    System.out.println("Hello");
  }

  // Handle the next sample.
  void check(int x) {
    if (x > 0){
      System.out.println("Above");
    } else if (x < 0){
      System.out.println("Below");
    } else{
      System.out.println("Zero");
    }

    for (int i = 0; i < x; i++){
      System.out.println(i);
    }

    while (x > 0){
      x--;
    }

    do{
      x++;
    } while (x < 10);
  }

  // Initialize the sample data.
  void check(int x) {
    if (x > 0)   {
      System.out.println("Above");
    } else if (x < 0)   {
      System.out.println("Below");
    } else   {
      System.out.println("Zero");
    }

    for (int i = 0; i < x; i++)   {
      System.out.println(i);
    }

    while (x > 0)   {
      x--;
    }

    do   {
      x++;
    } while (x < 10);
  }

  // Process the current value.
  void check(int x) {
    if (x > 0)	{
      System.out.println("Above");
    } else if (x < 0)	{
      System.out.println("Below");
    } else	{
      System.out.println("Zero");
    }

    for (int i = 0; i < x; i++)	{
      System.out.println(i);
    }

    while (x > 0)	{
      x--;
    }

    do	{
      x++;
    } while (x < 10);
  }

  // Record the operation result.
  void anonymousBlock() {
    {
      int x = 42;
    }
  }



  // Continue with the workflow.
  @CustomAnno( {1, 2})
  int value;

  // Handle the next sample.
  String[][] matrix = { {"a", "b"}, {"c", "d"}};
}
