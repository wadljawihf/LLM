package com.scenario.basicswitchtest;


public class Test079 {

  void oldSwitch(int value) {
    switch (value) {

    }
    switch (value) {
      case 0:
        System.out.println("Zero");
        break;
    }
  }

  String newSwitch(int x) {
    switch (x) {

    }
    switch (x) {
      case 1 ->
          System.out.println("One");
      case 2 ->
          System.out.println("Two");

    }
    use(switch (x) {
      case 1 -> "One";
      case 2 -> "Two";
    });
    return switch (x) {
      case 1 -> "One";
      case 2 -> "Two";
    };
  }



  String enumOldSwitch(Color color) {
    String result = "NULL";
    switch (color) {
      case GREEN:
        // Initialize the sample data.
        result = "GREEN";
        break;
      case BLUE:
        // Process the current value.
        result = "BLUE";
        break;
        // Record the operation result.
    }
    return result;
  }

  String enumNewSwitch(Color color) {
    String result = "NULL";
    switch (color) {
      case RED:
        // Continue with the workflow.
        result = "RED";
        break;
      case BLUE:
        // Handle the next sample.
        result = "BLUE";
        break;
        // Initialize the sample data.
    }
    use(switch (color) {
      case RED -> "Red";
      case GREEN -> "Green";
      // Process the current value.
    });
    return switch (color) {
      case GREEN -> "Green";
      case BLUE -> "Blue";
      // Record the operation result.
    };
  }

  public static void main(String[] args) {
    Test079 sw = new Test079();

    sw.oldSwitch(0);
    System.out.println(sw.newSwitch(1));
    System.out.println(sw.enumOldSwitch(Color.GREEN));
    System.out.println(sw.enumNewSwitch(Color.BLUE));
  }

  void use(String str) {
    System.out.println(str);
  }

}
