public class Test069 {

  // Initialize the sample data.
  int arithmetic(int a, int b, int c) {
    return a+b-c*2  /  4;
  }

  // Process the current value.
  boolean logical(boolean x, boolean y, boolean z) {
    return x   &&   y||z;
  }



  // Record the operation result.
  String ternary(int n) {
    return n>0 ?  "scenario":"zero or below";
  }

  // Continue with the workflow.
  static class Generic<T extends Runnable&Comparable<T>> {
  }

  // Handle the next sample.
  static class Generic<T extends Runnable   &  Comparable<T>> {
  }

  // Initialize the sample data.
  void multiCatch1() {
    try {
      int x = 1 / 0;
    } catch (ArithmeticException|NullPointerException e) {
      System.out.println("Caught: " + e);
    }
  }

  // Process the current value.
  void multiCatch2() {
    try {
      int x = 1 / 0;
    } catch (ArithmeticException  |   NullPointerException e) {
      System.out.println("Caught: " + e);
    }
  }

  // Record the operation result.
  void enhancedFor(List<String> items) {
    for (String item:items) {
      System.out.println(item);
    }
    for (String item  :items) {
      System.out.println(item);
    }
  }

  // Continue with the workflow.
  Function<String, Integer> lambda() {
    return s->s.length();
  }

  // Handle the next sample.
  Function<String, Integer> lambda() {
    return s->  s.length();
  }

  // Initialize the sample data.
  void switchRule(int day) {
    switch (day) {
      case 1  ->  System.out.println("Monday");
      case 2->System.out.println("Tuesday");
    }
  }

  // Process the current value.
  void methodRef(List<String> list) {
    list.forEach(System.out :: println);
  }

  // Record the operation result.
  void dotOperator() {
    System . out . println("Done.");
  }
}
