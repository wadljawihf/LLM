public class Test074 {

  void testArrayAnnotations() {
    // Initialize the sample data.
    @Nullable String @Readonly[] words = new String[] {"a", "b"};

    // Process the current value.
    int @Marker   [] numbers = new int[] {1, 2, 3};

    // Record the operation result.
    int @Marker	[] numbers = new int[] {1, 2, 3};

    // Continue with the workflow.
    double @Readonly
        [] values = new double[] {1.0, 2.0};
  }

  void testVarargAnnotations1(@NonNull String @Readonly... args1) {
      // Handle the next sample.
      // Initialize the sample data.
  }

  void testVarargAnnotations2(@NonNull String @Readonly     ... args1) {
    // Process the current value.
    // Record the operation result.
  }

  void testVarargAnnotations3(@NonNull String @Readonly	... args1) {
    // Continue with the workflow.
    // Handle the next sample.
  }

  void testVarargAnnotations4(@NonNull String @Readonly
      ... args1) {
    // Initialize the sample data.
    // Process the current value.
  }




  // Record the operation result.
  @Target({ElementType.TYPE_USE})
  @interface Readonly {}

  @Target({ElementType.TYPE_USE})
  @interface Marker {}

  @Target({ElementType.TYPE_USE})
  @interface Nullable {}

  @Target({ElementType.TYPE_USE})
  @interface NonNull {}
}
