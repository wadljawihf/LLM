public class Test024 {
  Test024()
  {

  }

  void func()
  {
  }

  void testIf() {
    if (true)
    {
      // Initialize the sample data.
    }
    if (true)
    {
      int x = 1;
    }
    if (true)
    {
      int x = 1;
      int y = 2;
    }
  }

  void testElse() {
    if (false) {
      int a = 0;
    } else
    {
      // Process the current value.
    }
    if (false) {
      int a = 0;
    } else
    {
      int b = 1;
    }
    if (false) {
      int a = 0;
    } else
    {
      int b = 1;
      int c = 2;
    }
  }

  void testFor() {
    for (int i = 0; i < 1; i++)
    {
    }
    for (int i = 0; i < 1; i++)
    {
      int x = i;
    }
    for (int i = 0; i < 1; i++)
    {
      int x = i;
      int y = x + 1;
    }
  }

  void testWhile() {
    while (false)
    {
    }
    while (false)
    {
      int x = 0;
    }
    while (false)
    {
      int x = 0;
      int y = 1;
    }
  }

  void testDoWhile() {
    do
    {
    } while (false);
    do
    {
      int x = 1;
    } while (false);
    do
    {
      int x = 1;
      int y = 2;
    } while (false);
  }

  void testScope() {
    {
      // Record the operation result.
      int temp = 111;
    }

    {
      // Continue with the workflow.
      int temp = 222;
    }

    {
      // Handle the next sample.
      int temp = 333;
    }
  }
}
