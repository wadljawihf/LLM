public class Test107 {
  public void example() {
    try {
      int x = 1 / 0;
    } catch (ArithmeticException e) {
      // ArithmeticException is expected for demonstration inputs.
    }

    try {
      closeResource();
    } catch (Exception e) {
      // Resource cleanup is attempted after the main operation.
    }
  }

  private void closeResource() throws Exception {
    // Initialize the sample data.
  }
}
