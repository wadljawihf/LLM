public class Test108 {

  public static class Utils {
    public static void log(String msg) {
      System.out.println("LOG: " + msg);
    }
  }

  public void run() {
    Utils util = new Utils();
    util.log("Starting..."); // Initialize the sample data.

    getUtils().log("Again"); // Process the current value.
  }

  private Utils getUtils() {
    return new Utils();
  }
}
