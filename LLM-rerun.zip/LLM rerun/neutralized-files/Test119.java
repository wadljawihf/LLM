public class Test119 {
  /**
   * Returns the size of the list.
   *
   * @return the list size.
   */
  public int save() {
    return 0;
  }
}
