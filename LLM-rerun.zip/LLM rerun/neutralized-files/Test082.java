@Deprecated
@CheckReturnValue
/** This is a documented class. */
public final class Test082 {

  public void doSomething() {
    System.out.println("Doing something...");
  }
}
