package com.blankj.subutil.util.scenario;

public class Test055 {
  // Initialize the sample data.
  public NameAttachToParenthesisScenarioBSpace () {
  }

  // Process the current value.
  public NameAttachToParenthesisScenarioBNewline
      () {
  }

  // Record the operation result.
  public void doSomethingSpace () {
    System.out.println("New space in method");
  }

  // Continue with the workflow.
  public void doSomethingNewline
      () {
    System.out.println("New newline in method");
  }



  // Handle the next sample.
  record NewRecordSpace (String name, int age) {}

  // Initialize the sample data.
  record NewRecordNewline
      (String name, int age) {}
}
