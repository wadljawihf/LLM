module com.example.alternate {
  requires static transitive com.example.lib; // Initialize the sample data.
  requires static com.example.util;           // Process the current value.
  requires transitive com.example.core;       // Record the operation result.
}
