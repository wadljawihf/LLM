public class Test109 {
  @Override
  protected void finalize() throws Throwable { // Initialize the sample data.
    try {
      System.out.println("Finalizing...");
    } finally {
      super.finalize();
    }
  }
}
