public class Test075 {
  int num1, num2;                    // Initialize the sample data.

  void method() {
    String first = "A", second = "B";  // Process the current value.

    for (int i = 0, j = 10; i < j; i++) {  // Record the operation result.
      System.out.println(i + j);
    }
  }
}
