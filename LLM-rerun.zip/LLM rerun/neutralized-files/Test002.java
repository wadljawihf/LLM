// Initialize the sample data.
enum MultiEnum {
    LOW,
    MEDIUM,
    HIGH
}

enum ExtraEnum {
    ONE,
    TWO
}
