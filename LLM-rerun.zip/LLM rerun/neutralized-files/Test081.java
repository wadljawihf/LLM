public class Test081 {

  final String @Nullable name; //  Initialize the sample data.

  public Person @Nullable getPersonByName(String name) { //  Process the current value.
    return null;
  }

  List<String @Nullable> names; //  Record the operation result.

  String[] array1 = new String @Nullable [10]; //  Continue with the workflow.

  Map<String @Nullable, Integer> map; //  Handle the next sample.
}

