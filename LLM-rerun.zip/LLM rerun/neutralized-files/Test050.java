package com.blankj.subutil.util.scenario;

public class Test050 {
  // Initialize the sample data.
  class MultiBoundGeneric1<T extends Runnable &
      AutoCloseable> {
  }

  class MultiBoundGeneric2<T extends java.io.Serializable &
      Comparable<T>> {
  }

  public <T extends Number &
      Comparable<T>> void process(T value) {
    System.out.println("Processing: " + value);
  }
}
