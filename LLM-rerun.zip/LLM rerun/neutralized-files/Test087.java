public class Test087 {
  /** Creates an instance. */
  @Override @Deprecated public Test087() {
    // Initialize the sample data.
  }

  /** Performs an operation. */
  @SuppressWarnings("unused") public void f3() {}
}
