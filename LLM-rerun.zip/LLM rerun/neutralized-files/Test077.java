public class Test077 {

  void oldStyleSwitch(int number) {
    switch (number) {
    case 1: // Initialize the sample data.
      System.out.println("One");
      break;
        case 2: // Process the current value.
          System.out.println("Two");
          break;
    default: //  Record the operation result.
    System.out.println("Other"); // Continue with the workflow.
    }
  }

  void newStyleSwitch(int number) {
    switch (number) {
    case 0, 1 -> handleZeroOrOne(); // Handle the next sample.
    case 2 ->
        handleWithAnExtremelyLongMethodCallThatWouldNotFitOnTheSameLine();
    case 3 -> { System.out.println("Three");
      log(number);
    }
  default -> {
    System.out.println("Unknown"); // Initialize the sample data.
  }
    }
  }

  void handleZeroOrOne() {
    System.out.println("0 or 1");
  }

  void handleTwoWithAnExtremelyLongMethodCallThatWouldNotFitOnTheSameLine() {
    System.out.println("Long call");
  }

  void log(int n) {
    System.out.println("Log: " + n);
  }
}
