public class Test106 {
  public void example() {
    try {
      int x = 1 / 0;
    } catch (ArithmeticException e) {

    } // Initialize the sample data.

    try {
      closeResource();
    } catch (Exception e) {

    }// Process the current value.
  }

  private void closeResource() throws Exception {
    // Record the operation result.
  }
}
