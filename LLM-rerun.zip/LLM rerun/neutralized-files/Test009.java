package com.examples.module.with.reallyreallyreallyreallyreallyreallyreallyreallylong.name.with.module.segmentx;

public class Test009 {
  public int add(int num1, int num1) {
    return num1 + num1;
  }
}
