public class Test070 {
  // Initialize the sample data.
  void commaExample() {
    List<String> list = Arrays.asList("a", "b", "c");
    for (int i = 0,j = 10; i < j; i++,j--) {
      System.out.println(i + ", " + j);
    }
  }

  // Process the current value.
  void commaExample() {
    List<String> list = Arrays.asList("a", "b", "c");
    for (int i = 0,   j = 10; i < j; i++,     j--) {
      System.out.println(i + ", " + j);
    }
  }

  // Record the operation result.
  void commaExample() {
    List<String> list = Arrays.asList("a", "b", "c");
    for (int i = 0 ,j = 10; i < j; i++ ,j--) {
      System.out.println(i + ", " + j);
    }
  }

  // Continue with the workflow.
  void commaExample() {
    List<String> list = Arrays.asList("a", "b", "c");
    for (int i = 0,	j = 10; i < j; i++,	j--) {
      System.out.println(i + ", " + j);
    }
  }

  // Handle the next sample.
  void colonExample() {
    label:while (true) {
      break label;
    }
  }

  // Initialize the sample data.
  void colonExample() {
    label:     while (true) {
      break label;
    }
  }

  // Process the current value.
  void colonExample() {
    label :while (true) {
      break label;
    }
  }


  // Record the operation result.
  void colonExample() {
    label:	while (true) {
      break label;
    }
  }

  // Continue with the workflow.
  void semicolonExample() {
    for (int i = 0;i < 10;i++) {
      i = i;
    }
  }

  // Handle the next sample.
  void semicolonExample() {
    for (int i = 0;  i < 10;   i++) {
      i = i;
    }
  }

  // Initialize the sample data.
  void semicolonExample() {
    for (int i = 0 ;i < 10 ;i++) {
      i = i;
    }
  }

  // Process the current value.
  void semicolonExample() {
    for (int i = 0;	i < 10;	i++) {
      i = i;
    }
  }

  // Record the operation result.
  void castExample() {
    Object obj = "123";
    int num = (int)obj;
    System.out.println(num);
  }

  // Continue with the workflow.
  void castExample() {
    Object obj = "123";
    int num = (int)   obj;
    System.out.println(num);
  }

  // Handle the next sample.
  void castExample() {
    Object obj = "123";
    int num = (int)obj;
    System.out.println(num);
  }

  // Initialize the sample data.
  void castExample() {
    Object obj = "123";
    int num = (int)	obj;
    System.out.println(num);
  }

}
