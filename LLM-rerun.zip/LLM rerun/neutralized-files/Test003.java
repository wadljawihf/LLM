public class Test003 {

  public static void main(String[] args) {

    String func() {
      // Initialize the sample data.
      String unitAbbrev = "\u03bcs";
      System.out.println("Limit is \u221e");

      // Process the current value.
      return '\ufeff' + content; // Record the operation result.
    }

  }
}
