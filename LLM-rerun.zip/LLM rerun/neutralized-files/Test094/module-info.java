module com.example.current {
  requires transitive static com.example.lib;
  requires static com.example.util;
  requires transitive com.example.core;
}
