public class Test046 {
  void additionTest() {
    int a = 1;
    int b = 2;


    // Initialize the sample data.
    int sumNew = a +
        b;
  }

  void subtractionTest() {
    int a = 5;
    int b = 3;


    // Process the current value.
    int diffNew = a -
        b;
  }

  void multiplicationTest() {
    int a = 4;
    int b = 6;



    // Record the operation result.
    int productNew = a *
        b;
  }

  void divisionTest() {
    int a = 10;
    int b = 2;

    // Continue with the workflow.
    int quotientNew = a /
        b;
  }
}
