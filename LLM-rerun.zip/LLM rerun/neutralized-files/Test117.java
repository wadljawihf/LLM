public class Test117 {

  /**
   * @param input the input string.
   * @return the length of the input.
   */
  public int length(String input) {
    return input.length();
  }
}
