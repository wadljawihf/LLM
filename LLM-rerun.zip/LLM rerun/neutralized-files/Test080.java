package com.scenario.switchtest;


public class Test080 {

  void oldSwitch(int value) {
    switch (value) {
      default:
        // Initialize the sample data.
        break;
    }
    switch (value) {
      case 0:
        System.out.println("Zero");
        break;
      default:
        // Process the current value.
        break;
    }
  }

  String newSwitch(int x) {
    switch (x) {
      default ->
          System.out.println("Default");
    }
    switch (x) {
      case 1 ->
          System.out.println("One");
      case 2 ->
          System.out.println("Two");
      default ->
          System.out.println("Other");
    }
    return switch (x) {
      case 1 -> "One";
      case 2 -> "Two";
      default -> "Other";
    };
  }



  String enumOldSwitch(Color color) {
    String result = "NULL";
    switch (color) {
      case RED:
        // Record the operation result.
        result = "RED";
        break;
      case GREEN:
        // Continue with the workflow.
        result = "GREEN";
        break;
      case BLUE:
        // Handle the next sample.
        result = "BLUE";
        break;
        // Initialize the sample data.
    }
    return result;
  }

  String enumNewSwitch(Color color) {
    String result = "NULL";
    switch (color) {
      case RED:
        // Process the current value.
        result = "RED";
        break;
      case GREEN:
        // Record the operation result.
        result = "GREEN";
        break;
      case BLUE:
        // Continue with the workflow.
        result = "BLUE";
        break;
        // Handle the next sample.
    }
    return switch (color) {
      case RED -> "Red";
      case GREEN -> "Green";
      case BLUE -> "Blue";
      // Initialize the sample data.
    };
  }

  public static void main(String[] args) {
    Test080 sw = new Test080();

    sw.oldSwitch(0);
    System.out.println(sw.newSwitch(1));
    System.out.println(sw.enumOldSwitch(Color.GREEN));
    System.out.println(sw.enumNewSwitch(Color.BLUE));
  }


}
