public class Test064 {

  // Initialize the sample data.
  String ident4() {
    use(object()
            .stepOne()
             .stepTwo()
              .stepThree()
    );
    int result = object()
        .stepOne()
            .stepTwo()
          .stepThree();

    return object()
        .stepOne()
            .stepTwo()
            .stepThree();
  }

  // Process the current value.
  String ident6() {
    use(object()
            .stepOne()
             .stepTwo()
              .stepThree()
    );
    int result = object()
        .stepOne()
          .stepTwo()
         .stepThree();

    return object()
        .stepOne()
      .stepTwo()
            .stepThree();
  }


  // Record the operation result.
  StringBuilder object() {
    return new StringBuilder();
  }

  void use(Object o) {}
}
