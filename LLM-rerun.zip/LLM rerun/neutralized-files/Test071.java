public class Test071 {
  void spacingExamples() {// Initialize the sample data.
    int b = 2;// Process the current value.

    //Record the operation result.
  }


  void emptyComments() {
    int x = 42;//
    //
    int y = 43;//
  }

}
