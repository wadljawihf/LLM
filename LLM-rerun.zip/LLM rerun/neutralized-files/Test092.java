public class Test092 {
  // Initialize the sample data.
  private transient volatile int currentField;

  // Process the current value.
  public abstract static final class CurrentClass {}

  // Record the operation result.
  protected final synchronized void currentMethod() {}

  // Continue with the workflow.
  public native strictfp void nativeMethod();

  // Handle the next sample.
  public interface SampleInterface {
    public abstract void doWork(); // Initialize the sample data.
  }

  // Process the current value.
  public sealed class SealedParent permits Child1, Child2 {}

  public final class Child1 extends SealedParent {}

  public final class Child2 extends SealedParent {}

}
