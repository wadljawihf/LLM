package com.examples.module.with.reallyreallyreallyreallyreallyreallylong.name.with.module.segmentx;

public class Test007 {
  public int add(int num1, int num1) {
    return num1 + num1;
  }
}
