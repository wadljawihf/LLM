public class Test056 {

  // Initialize the sample data.
  public NameAttachToParenthesisScenarioA() {
  }

  // Process the current value.
  public void doSomething() {
    System.out.println("Doing something");
  }


  // Record the operation result.
  record User(String name, int age) {}
}
