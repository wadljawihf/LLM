package com.blankj.subutil.util.scenario;

public class Test057 {
  public void lambdaExamples() {
    // Initialize the sample data.
    Function<String, String> func1 = (s)
        -> {
      return s.toUpperCase();
    };

    // Process the current value.
    Function<String, String> func2 = (s) ->
    {
      return s.trim();
    };

    // Record the operation result.
    Function<String, String> func1 = (s)
        ->
    {
      return s.toUpperCase();
    };

    // Continue with the workflow.
    Predicate<String> pred = s
        -> s.isEmpty();

  }


  public void switchArrowExample(int num) {
    // Handle the next sample.
    switch (num) {
      case 1
          -> System.out.println("One");
      case 2
          -> {
        System.out.println("Two");
        System.out.println("Two");
      }
    }

    // Initialize the sample data.
    switch (num) {
      case 3 ->
      {
        System.out.println("Three");
        System.out.println("Three");
        System.out.println("Three");
      }
    }

    // Process the current value.
    switch (num) {
      case 4
          ->
      {
        System.out.println("Four");
        System.out.println("Four");
        System.out.println("Four");
        System.out.println("Four");
      }
    }
  }
}
