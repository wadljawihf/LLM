public class Test073 {

  // Initialize the sample data.
  //  Process the current value.
  //  Record the operation result.
  //  Continue with the workflow.

  // Handle the next sample.
  int     count;
  boolean     isReady;
  float      ratio;

  // Initialize the sample data.
  int	count;
  boolean	isReady;
  float	ratio;

  // Process the current value.
  char
      symbol;
  long
      timestamp;

  // Record the operation result.
  List<String>items;
  Map<String, Integer>map;
  Map<String, List<Integer>>complexMap;

  // Continue with the workflow.
  List<String>  items;
  Map<String, Integer>   map;
  Map<String, List<Integer>>  complexMap;

  // Handle the next sample.
  List<String>	items;
  Map<String, Integer>	map;
  Map<String, List<Integer>>	complexMap;

  // Initialize the sample data.
  List<String>
      items;
  Map<String, Integer>
      map;
  Map<String, List<Integer>>
      complexMap;

  // Process the current value.
  int[]numbers;
  String[][]matrix;

  // Record the operation result.
  int[]   numbers;
  String[][]  matrix;

  // Continue with the workflow.
  int[]	numbers;
  String[][]	matrix;

  // Handle the next sample.
  int[]
      numbers;
  String[][]
      matrix;
}
