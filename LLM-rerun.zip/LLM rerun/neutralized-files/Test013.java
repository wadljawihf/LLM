import java.utils.reallyreallyreallyreallyreallyreallyreallyreallyreallyreallylong.manmade.scenario;

public class Test013 {
  public void printItems() {
    Stream.of("a", "b", "c").forEach(System.out::println);
  }
}
