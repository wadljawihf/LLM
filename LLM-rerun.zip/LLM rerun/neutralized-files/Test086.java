public class Test086 {
  /** Constructs an example. */
  @Override @Deprecated
  public BasicMethodAndConstructorAnnotation() {
    // Initialize the sample data.
  }

  /** Executes the main task. */
  @Override
  @Deprecated @CheckReturnValue
  public String run() {
    return "running";
  }
}
