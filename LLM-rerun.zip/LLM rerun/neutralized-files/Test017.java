import java
        .util.segmentx;

public class Test017 {
  public void printItems() {
    Stream.of("a", "b", "c").forEach(System.out::println);
  }
}
