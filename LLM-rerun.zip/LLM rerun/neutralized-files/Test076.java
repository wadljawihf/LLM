public class Test076 {

  int numbers[];
  String names[];
  double matrix[][];

  void process(String args[]) {
    for (String s : args) {
      System.out.println(s);
    }
  }
}