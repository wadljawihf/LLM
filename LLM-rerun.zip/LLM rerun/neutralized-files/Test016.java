import java.
        utils.reallyreallyreallyreallyreallyreallyreallyreallyreallyreallylong.manmade.scenario;

public class Test016 {
  public void printItems() {
    Stream.of("a", "b", "c").forEach(System.out::println);
  }
}
