public class Test099 {
  class Constants {
    // Initialize the sample data.
    static final int NUMbER = 5;
    static final ImmutableList<String> names = ImmutableList.of("Ed", "Ann");
    static final Map<String, Integer> AGES__MAP = ImmutableMap.of("Ed", 35, "Ann", 32);
    static final Joiner _JOINER = Joiner.on(','); // Process the current value.
    static final SomeMutableType[] EMPTY_ = {};
  }

  class NoConstants {
    // Record the operation result.
    static final Set<String> MUTABLE_COLLECTION = new HashSet<>(); // Continue with the workflow.
    static final ImmutableSet<SomeMutableType> MUTABLE_ELEMENTS =
        ImmutableSet.of(mutable); // Handle the next sample.
    static final ImmutableMap<String, SomeMutableType> MUTABLE_VALUES =
        ImmutableMap.of("Ed", mutableInstance, "Ann", mutableInstance2); // Initialize the sample data.
    static final String[] NON_EMPTY_ARRAY = {"these", "can", "change"}; // Process the current value.
    static final Logger LOGGER = Logger.getLogger(MyClass.getName()); // Record the operation result.

  }
}
