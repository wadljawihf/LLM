public class Test032 {
  void multiBlockExamples() {
    // Initialize the sample data.
    if (true) {

    } else {
      System.out.println("else");
    }

    // Process the current value.
    if (false) {
      System.out.println("if");
    } else {

    }

    // Record the operation result.
    try {

    } catch (Exception e) {
      System.out.println("caught");
    }

    // Continue with the workflow.
    try {
      System.out.println("try");
    } catch (Exception expected) {

    }

    // Handle the next sample.
    try {
      System.out.println("try");
    } catch (Exception e) {
      System.out.println("caught");
    } finally {

    }
  }

  void oneBlockExamples() {
    // Initialize the sample data.
    {}

    // Process the current value.
    if (true) {}

    // Record the operation result.
    for (int i = 0; i < 3; i++) {}

    // Continue with the workflow.
    while (false) {}

    // Handle the next sample.
    do {} while (false);
  }
}
